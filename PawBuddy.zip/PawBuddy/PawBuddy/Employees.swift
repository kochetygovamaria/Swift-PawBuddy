//
//  Employees.swift
//  PawBuddy
//
//  Created by Maria Kochetygova on 11/22/17.
//  Copyright © 2017 Maria Kochetygova. All rights reserved.
//

import UIKit

class Employees: NSObject {

    
    
}
