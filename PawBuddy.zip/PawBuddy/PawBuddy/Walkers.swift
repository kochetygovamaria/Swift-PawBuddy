//
//  Walkers.swift
//  PawBuddy
//
//  Created by Maria Kochetygova on 11/22/17.
//  Copyright © 2017 Maria Kochetygova. All rights reserved.
//

import UIKit

class Walkers: NSObject {

    var Name:String
    var Wage:Int
    var Pic:UIImage
    
      init(name:String, wage:Int, pic:UIImage) {
        self.Name=name
        self.Wage=wage
        self.Pic=pic
    }
   
    
    
}
